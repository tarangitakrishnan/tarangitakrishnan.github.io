# Tarangita Krishnan Portfolio — GitHub Pages edition

This is a static archive of the portfolio exported from ChatGPT Sites, adapted for deployment to `https://tarangitakrishnan.github.io/`. It includes the website art, galleries, process albums, film pages, about page and resume. Images have been converted to WebP for smaller downloads, and animated GIF film shots have been converted to MP4.

## How to publish

Upload the **contents of this folder** to the root of your public `tarangitakrishnan/tarangitakrishnan.github.io` repository's `main` branch, then use **Settings > Pages > Build and deployment > Source: Deploy from a branch > main / (root)** and save.

GitHub Pages does not support the original Cloudflare R2 storage or Next.js API routes, so adding/removing art, changing layout online, and uploading GIFs through the website are not available. To change art, update files in the repository and republish.

No Cloudflare secrets or hosting bindings are included.
